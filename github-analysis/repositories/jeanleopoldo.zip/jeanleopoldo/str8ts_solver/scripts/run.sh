ghc --make main.hs -o program
./program
