# Str8ts
Str8ts game solver in haskell
